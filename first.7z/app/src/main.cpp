// main.cpp
// -----------------------------------------------------
// Copyright 2024 The GlassSurf Authors
// Use of this source code is governed by a MIT-style license that can be
// found in the LICENSE file.

#define __PROGRAM_NAME__ "GlassSurf"
#define __PROGRAM_VERSION__ "0"

int main(int argc, char const *argv[])
{
    return 0;
}
